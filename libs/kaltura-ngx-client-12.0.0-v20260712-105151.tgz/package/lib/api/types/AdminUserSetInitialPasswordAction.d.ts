import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaAuthentication } from './KalturaAuthentication';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AdminUserSetInitialPasswordActionArgs extends KalturaRequestArgs {
    hashKey: string;
    newPassword: string;
}
/**
 * Build request payload for service 'adminUser' action 'setInitialPassword'.
 *
 * Usage: Set initial users password
 *
 * Server response type:         KalturaAuthentication
 * Server failure response type: KalturaAPIException
 */
export declare class AdminUserSetInitialPasswordAction extends KalturaRequest<KalturaAuthentication> {
    hashKey: string;
    newPassword: string;
    constructor(data: AdminUserSetInitialPasswordActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
