import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCategory } from './KalturaCategory';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CategoryCloneActionArgs extends KalturaRequestArgs {
    categoryId: number;
    fromPartnerId: number;
    parentCategoryId?: number;
}
/**
 * Build request payload for service 'category' action 'clone'.
 *
 * Usage: Clone Category
 *
 * Server response type:         KalturaCategory
 * Server failure response type: KalturaAPIException
 */
export declare class CategoryCloneAction extends KalturaRequest<KalturaCategory> {
    categoryId: number;
    fromPartnerId: number;
    parentCategoryId: number;
    constructor(data: CategoryCloneActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
