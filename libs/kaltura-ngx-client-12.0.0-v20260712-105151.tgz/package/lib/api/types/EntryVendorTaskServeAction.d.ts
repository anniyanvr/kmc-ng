import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaFileRequest, KalturaFileRequestArgs } from '../kaltura-file-request';
export interface EntryVendorTaskServeActionArgs extends KalturaFileRequestArgs {
    vendorPartnerId?: number;
    partnerId?: number;
    status?: number;
    dueDate?: string;
}
/**
 * Build request payload for service 'entryVendorTask' action 'serve'.
 *
 *
 *
 * Server response type:         { url: string }
 * Server failure response type: KalturaAPIException
 */
export declare class EntryVendorTaskServeAction extends KalturaFileRequest {
    vendorPartnerId: number;
    partnerId: number;
    status: number;
    dueDate: string;
    constructor(data?: EntryVendorTaskServeActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
