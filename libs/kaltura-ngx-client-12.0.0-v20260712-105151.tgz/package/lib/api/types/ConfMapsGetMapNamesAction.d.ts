import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaString } from './KalturaString';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ConfMapsGetMapNamesActionArgs extends KalturaRequestArgs {
}
/**
 * Build request payload for service 'confMaps' action 'getMapNames'.
 *
 * Usage: List configuration maps names
 *
 * Server response type:         KalturaString[]
 * Server failure response type: KalturaAPIException
 */
export declare class ConfMapsGetMapNamesAction extends KalturaRequest<KalturaString[]> {
    constructor(data?: ConfMapsGetMapNamesActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
