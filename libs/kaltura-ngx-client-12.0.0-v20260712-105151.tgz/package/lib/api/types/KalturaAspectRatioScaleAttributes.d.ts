import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDimensionsAttributes, KalturaDimensionsAttributesArgs } from './KalturaDimensionsAttributes';
export interface KalturaAspectRatioScaleAttributesArgs extends KalturaDimensionsAttributesArgs {
    aspectRatio?: number;
}
export declare class KalturaAspectRatioScaleAttributes extends KalturaDimensionsAttributes {
    aspectRatio: number;
    constructor(data?: KalturaAspectRatioScaleAttributesArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
