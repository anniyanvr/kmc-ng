import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaConfMaps } from './KalturaConfMaps';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ConfMapsUpdateActionArgs extends KalturaRequestArgs {
    map: KalturaConfMaps;
}
/**
 * Build request payload for service 'confMaps' action 'update'.
 *
 * Usage: Update configuration map
 *
 * Server response type:         KalturaConfMaps
 * Server failure response type: KalturaAPIException
 */
export declare class ConfMapsUpdateAction extends KalturaRequest<KalturaConfMaps> {
    map: KalturaConfMaps;
    constructor(data: ConfMapsUpdateActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
