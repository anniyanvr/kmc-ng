import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaESearchGroupResponse } from './KalturaESearchGroupResponse';
import { KalturaESearchGroupParams } from './KalturaESearchGroupParams';
import { KalturaPager } from './KalturaPager';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ESearchSearchGroupActionArgs extends KalturaRequestArgs {
    searchParams: KalturaESearchGroupParams;
    pager?: KalturaPager;
}
/**
 * Build request payload for service 'eSearch' action 'searchGroup'.
 *
 *
 *
 * Server response type:         KalturaESearchGroupResponse
 * Server failure response type: KalturaAPIException
 */
export declare class ESearchSearchGroupAction extends KalturaRequest<KalturaESearchGroupResponse> {
    searchParams: KalturaESearchGroupParams;
    pager: KalturaPager;
    constructor(data: ESearchSearchGroupActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
