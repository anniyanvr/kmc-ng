import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ConfMapsGetBatchMapActionArgs extends KalturaRequestArgs {
    hostName: string;
}
/**
 * Build request payload for service 'confMaps' action 'getBatchMap'.
 *
 * Usage: Get batch configuration map
 *
 * Server response type:         string
 * Server failure response type: KalturaAPIException
 */
export declare class ConfMapsGetBatchMapAction extends KalturaRequest<string> {
    hostName: string;
    constructor(data: ConfMapsGetBatchMapActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
