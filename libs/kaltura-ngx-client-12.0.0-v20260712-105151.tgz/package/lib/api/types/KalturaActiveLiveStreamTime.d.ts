import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaObjectBase, KalturaObjectBaseArgs } from '../kaltura-object-base';
export interface KalturaActiveLiveStreamTimeArgs extends KalturaObjectBaseArgs {
    startTime?: number;
    endTime?: number;
}
export declare class KalturaActiveLiveStreamTime extends KalturaObjectBase {
    startTime: number;
    endTime: number;
    constructor(data?: KalturaActiveLiveStreamTimeArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
