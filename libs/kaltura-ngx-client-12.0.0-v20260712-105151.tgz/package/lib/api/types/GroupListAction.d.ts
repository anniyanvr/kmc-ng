import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaGroupListResponse } from './KalturaGroupListResponse';
import { KalturaGroupFilter } from './KalturaGroupFilter';
import { KalturaFilterPager } from './KalturaFilterPager';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface GroupListActionArgs extends KalturaRequestArgs {
    filter?: KalturaGroupFilter;
    pager?: KalturaFilterPager;
}
/**
 * Build request payload for service 'group' action 'list'.
 *
 * Usage: Lists group  objects that are associated with an account.
 * Blocked users are listed unless you use a filter to exclude them.
 * Deleted users are not listed unless you use a filter to include them
 *
 * Server response type:         KalturaGroupListResponse
 * Server failure response type: KalturaAPIException
 */
export declare class GroupListAction extends KalturaRequest<KalturaGroupListResponse> {
    filter: KalturaGroupFilter;
    pager: KalturaFilterPager;
    constructor(data?: GroupListActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
