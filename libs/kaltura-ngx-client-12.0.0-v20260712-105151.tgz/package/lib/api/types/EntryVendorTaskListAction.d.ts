import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEntryVendorTaskListResponse } from './KalturaEntryVendorTaskListResponse';
import { KalturaEntryVendorTaskFilter } from './KalturaEntryVendorTaskFilter';
import { KalturaFilterPager } from './KalturaFilterPager';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryVendorTaskListActionArgs extends KalturaRequestArgs {
    filter?: KalturaEntryVendorTaskFilter;
    pager?: KalturaFilterPager;
}
/**
 * Build request payload for service 'entryVendorTask' action 'list'.
 *
 * Usage: List KalturaEntryVendorTask objects
 *
 * Server response type:         KalturaEntryVendorTaskListResponse
 * Server failure response type: KalturaAPIException
 */
export declare class EntryVendorTaskListAction extends KalturaRequest<KalturaEntryVendorTaskListResponse> {
    filter: KalturaEntryVendorTaskFilter;
    pager: KalturaFilterPager;
    constructor(data?: EntryVendorTaskListActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
