import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEntryVendorTask } from './KalturaEntryVendorTask';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryVendorTaskRejectActionArgs extends KalturaRequestArgs {
    id: number;
    rejectReason?: string;
}
/**
 * Build request payload for service 'entryVendorTask' action 'reject'.
 *
 * Usage: Reject entry vendor task for execution
 *
 * Server response type:         KalturaEntryVendorTask
 * Server failure response type: KalturaAPIException
 */
export declare class EntryVendorTaskRejectAction extends KalturaRequest<KalturaEntryVendorTask> {
    id: number;
    rejectReason: string;
    constructor(data: EntryVendorTaskRejectActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
