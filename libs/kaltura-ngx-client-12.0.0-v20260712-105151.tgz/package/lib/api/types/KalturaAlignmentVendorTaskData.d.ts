import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaVendorTaskDataCaptionAsset, KalturaVendorTaskDataCaptionAssetArgs } from './KalturaVendorTaskDataCaptionAsset';
export interface KalturaAlignmentVendorTaskDataArgs extends KalturaVendorTaskDataCaptionAssetArgs {
    textTranscriptAssetId?: string;
    jsonTranscriptAssetId?: string;
}
export declare class KalturaAlignmentVendorTaskData extends KalturaVendorTaskDataCaptionAsset {
    textTranscriptAssetId: string;
    jsonTranscriptAssetId: string;
    constructor(data?: KalturaAlignmentVendorTaskDataArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
