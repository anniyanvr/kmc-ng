import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDimensionsAttributes, KalturaDimensionsAttributesArgs } from './KalturaDimensionsAttributes';
export interface KalturaAspectRatioCropAttributesArgs extends KalturaDimensionsAttributesArgs {
    aspectRatio?: number;
}
export declare class KalturaAspectRatioCropAttributes extends KalturaDimensionsAttributes {
    aspectRatio: number;
    constructor(data?: KalturaAspectRatioCropAttributesArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
