import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaGroup } from './KalturaGroup';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface GroupAddActionArgs extends KalturaRequestArgs {
    group: KalturaGroup;
}
/**
 * Build request payload for service 'group' action 'add'.
 *
 * Usage: Adds a new group (user of type group)
 *
 * Server response type:         KalturaGroup
 * Server failure response type: KalturaAPIException
 */
export declare class GroupAddAction extends KalturaRequest<KalturaGroup> {
    group: KalturaGroup;
    constructor(data: GroupAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
