import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEntryVendorTask } from './KalturaEntryVendorTask';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryVendorTaskApproveActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
 * Build request payload for service 'entryVendorTask' action 'approve'.
 *
 * Usage: Approve entry vendor task for execution
 *
 * Server response type:         KalturaEntryVendorTask
 * Server failure response type: KalturaAPIException
 */
export declare class EntryVendorTaskApproveAction extends KalturaRequest<KalturaEntryVendorTask> {
    id: number;
    constructor(data: EntryVendorTaskApproveActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
