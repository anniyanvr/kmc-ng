import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaStringValue } from './KalturaStringValue';
import { KalturaFeedDropFolder, KalturaFeedDropFolderArgs } from './KalturaFeedDropFolder';
export interface KalturaApFeedDropFolderArgs extends KalturaFeedDropFolderArgs {
    apApiKey?: string;
    itemsToExpand?: KalturaStringValue[];
}
export declare class KalturaApFeedDropFolder extends KalturaFeedDropFolder {
    apApiKey: string;
    itemsToExpand: KalturaStringValue[];
    constructor(data?: KalturaApFeedDropFolderArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
