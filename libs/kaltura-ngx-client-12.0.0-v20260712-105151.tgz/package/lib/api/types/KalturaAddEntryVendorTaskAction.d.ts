import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEntryObjectType } from './KalturaEntryObjectType';
import { KalturaRuleAction, KalturaRuleActionArgs } from './KalturaRuleAction';
export interface KalturaAddEntryVendorTaskActionArgs extends KalturaRuleActionArgs {
    catalogItemIds?: string;
    entryObjectType?: KalturaEntryObjectType;
}
export declare class KalturaAddEntryVendorTaskAction extends KalturaRuleAction {
    catalogItemIds: string;
    entryObjectType: KalturaEntryObjectType;
    constructor(data?: KalturaAddEntryVendorTaskActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
