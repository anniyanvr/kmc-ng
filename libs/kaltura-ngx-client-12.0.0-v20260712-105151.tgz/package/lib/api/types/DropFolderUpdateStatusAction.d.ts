import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDropFolderStatus } from './KalturaDropFolderStatus';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DropFolderUpdateStatusActionArgs extends KalturaRequestArgs {
    dropFolderId: number;
    status: KalturaDropFolderStatus;
}
/**
 * Build request payload for service 'dropFolder' action 'updateStatus'.
 *
 *
 *
 * Server response type:         void
 * Server failure response type: KalturaAPIException
 */
export declare class DropFolderUpdateStatusAction extends KalturaRequest<void> {
    dropFolderId: number;
    status: KalturaDropFolderStatus;
    constructor(data: DropFolderUpdateStatusActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
