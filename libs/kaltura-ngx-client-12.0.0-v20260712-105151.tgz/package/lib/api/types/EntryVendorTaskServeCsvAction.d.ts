import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryVendorTaskServeCsvActionArgs extends KalturaRequestArgs {
    id: string;
}
/**
 * Build request payload for service 'entryVendorTask' action 'serveCsv'.
 *
 * Usage: Will serve a requested csv
 *
 * Server response type:         string
 * Server failure response type: KalturaAPIException
 */
export declare class EntryVendorTaskServeCsvAction extends KalturaRequest<string> {
    id: string;
    constructor(data: EntryVendorTaskServeCsvActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
