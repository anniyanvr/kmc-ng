import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBeaconListResponse } from './KalturaBeaconListResponse';
import { KalturaBeaconSearchParams } from './KalturaBeaconSearchParams';
import { KalturaPager } from './KalturaPager';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BeaconSearchScheduledResourceActionArgs extends KalturaRequestArgs {
    searchParams: KalturaBeaconSearchParams;
    pager?: KalturaPager;
}
/**
 * Build request payload for service 'beacon' action 'searchScheduledResource'.
 *
 *
 *
 * Server response type:         KalturaBeaconListResponse
 * Server failure response type: KalturaAPIException
 */
export declare class BeaconSearchScheduledResourceAction extends KalturaRequest<KalturaBeaconListResponse> {
    searchParams: KalturaBeaconSearchParams;
    pager: KalturaPager;
    constructor(data: BeaconSearchScheduledResourceActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
