import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaFileRequest, KalturaFileRequestArgs } from '../kaltura-file-request';
export interface CaptionAssetServeAsJsonActionArgs extends KalturaFileRequestArgs {
    captionAssetId: string;
}
/**
 * Build request payload for service 'captionAsset' action 'serveAsJson'.
 *
 * Usage: Serves caption file as Json by its ID
 *
 * Server response type:         { url: string }
 * Server failure response type: KalturaAPIException
 */
export declare class CaptionAssetServeAsJsonAction extends KalturaFileRequest {
    captionAssetId: string;
    constructor(data: CaptionAssetServeAsJsonActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
