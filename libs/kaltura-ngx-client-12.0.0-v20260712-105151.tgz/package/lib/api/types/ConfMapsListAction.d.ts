import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaConfMapsListResponse } from './KalturaConfMapsListResponse';
import { KalturaConfMapsFilter } from './KalturaConfMapsFilter';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ConfMapsListActionArgs extends KalturaRequestArgs {
    filter: KalturaConfMapsFilter;
}
/**
 * Build request payload for service 'confMaps' action 'list'.
 *
 * Usage: List configuration maps
 *
 * Server response type:         KalturaConfMapsListResponse
 * Server failure response type: KalturaAPIException
 */
export declare class ConfMapsListAction extends KalturaRequest<KalturaConfMapsListResponse> {
    filter: KalturaConfMapsFilter;
    constructor(data: ConfMapsListActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
