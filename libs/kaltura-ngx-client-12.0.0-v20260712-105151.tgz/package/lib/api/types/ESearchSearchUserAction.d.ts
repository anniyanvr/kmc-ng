import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaESearchUserResponse } from './KalturaESearchUserResponse';
import { KalturaESearchUserParams } from './KalturaESearchUserParams';
import { KalturaPager } from './KalturaPager';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ESearchSearchUserActionArgs extends KalturaRequestArgs {
    searchParams: KalturaESearchUserParams;
    pager?: KalturaPager;
}
/**
 * Build request payload for service 'eSearch' action 'searchUser'.
 *
 *
 *
 * Server response type:         KalturaESearchUserResponse
 * Server failure response type: KalturaAPIException
 */
export declare class ESearchSearchUserAction extends KalturaRequest<KalturaESearchUserResponse> {
    searchParams: KalturaESearchUserParams;
    pager: KalturaPager;
    constructor(data: ESearchSearchUserActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
