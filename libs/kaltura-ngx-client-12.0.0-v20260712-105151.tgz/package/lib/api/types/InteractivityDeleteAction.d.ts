import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface InteractivityDeleteActionArgs extends KalturaRequestArgs {
    entryId: string;
}
/**
 * Build request payload for service 'interactivity' action 'delete'.
 *
 * Usage: Delete a interactivity object by entry id
 *
 * Server response type:         void
 * Server failure response type: KalturaAPIException
 */
export declare class InteractivityDeleteAction extends KalturaRequest<void> {
    entryId: string;
    constructor(data: InteractivityDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
