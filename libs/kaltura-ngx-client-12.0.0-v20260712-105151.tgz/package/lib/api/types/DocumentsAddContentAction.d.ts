import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDocumentEntry } from './KalturaDocumentEntry';
import { KalturaResource } from './KalturaResource';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DocumentsAddContentActionArgs extends KalturaRequestArgs {
    entryId: string;
    resource?: KalturaResource;
}
/**
 * Build request payload for service 'documents' action 'addContent'.
 *
 * Usage: Add content to document entry which is not yet associated with content (therefore is in status NO_CONTENT).
 * If the requirement is to replace the entry's associated content, use action updateContent
 *
 * Server response type:         KalturaDocumentEntry
 * Server failure response type: KalturaAPIException
 */
export declare class DocumentsAddContentAction extends KalturaRequest<KalturaDocumentEntry> {
    entryId: string;
    resource: KalturaResource;
    constructor(data: DocumentsAddContentActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
