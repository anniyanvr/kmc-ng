import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCuePointListResponse } from './KalturaCuePointListResponse';
import { KalturaUploadRequest, KalturaUploadRequestArgs } from '../kaltura-upload-request';
export interface AnnotationAddFromBulkActionArgs extends KalturaUploadRequestArgs {
    fileData: File;
}
/**
 * Build request payload for service 'annotation' action 'addFromBulk'.
 *
 * Usage: Allows you to add multiple cue points objects by uploading XML that contains multiple cue point definitions
 *
 * Server response type:         KalturaCuePointListResponse
 * Server failure response type: KalturaAPIException
 */
export declare class AnnotationAddFromBulkAction extends KalturaUploadRequest<KalturaCuePointListResponse> {
    fileData: File;
    constructor(data: AnnotationAddFromBulkActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
