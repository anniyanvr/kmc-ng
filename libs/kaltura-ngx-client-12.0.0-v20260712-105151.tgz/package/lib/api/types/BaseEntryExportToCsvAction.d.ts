import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBaseEntryFilter } from './KalturaBaseEntryFilter';
import { KalturaCsvAdditionalFieldInfo } from './KalturaCsvAdditionalFieldInfo';
import { KalturaKeyValue } from './KalturaKeyValue';
import { KalturaExportToCsvOptions } from './KalturaExportToCsvOptions';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BaseEntryExportToCsvActionArgs extends KalturaRequestArgs {
    filter?: KalturaBaseEntryFilter;
    metadataProfileId?: number;
    additionalFields?: KalturaCsvAdditionalFieldInfo[];
    mappedFields?: KalturaKeyValue[];
    options?: KalturaExportToCsvOptions;
}
/**
 * Build request payload for service 'baseEntry' action 'exportToCsv'.
 *
 * Usage: add batch job that sends an email with a link to download an updated CSV that contains list of entries
 *
 * Server response type:         string
 * Server failure response type: KalturaAPIException
 */
export declare class BaseEntryExportToCsvAction extends KalturaRequest<string> {
    filter: KalturaBaseEntryFilter;
    metadataProfileId: number;
    additionalFields: KalturaCsvAdditionalFieldInfo[];
    mappedFields: KalturaKeyValue[];
    options: KalturaExportToCsvOptions;
    constructor(data?: BaseEntryExportToCsvActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
