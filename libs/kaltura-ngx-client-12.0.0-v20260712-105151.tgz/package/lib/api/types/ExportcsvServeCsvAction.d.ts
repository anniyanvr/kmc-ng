import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ExportcsvServeCsvActionArgs extends KalturaRequestArgs {
    id: string;
}
/**
 * Build request payload for service 'exportcsv' action 'serveCsv'.
 *
 * Usage: Will serve a requested CSV
 *
 * Server response type:         string
 * Server failure response type: KalturaAPIException
 */
export declare class ExportcsvServeCsvAction extends KalturaRequest<string> {
    id: string;
    constructor(data: ExportcsvServeCsvActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
