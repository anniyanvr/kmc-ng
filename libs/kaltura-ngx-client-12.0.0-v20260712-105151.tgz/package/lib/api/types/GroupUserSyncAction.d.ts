import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBulkUpload } from './KalturaBulkUpload';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface GroupUserSyncActionArgs extends KalturaRequestArgs {
    userId: string;
    groupIds?: string;
    removeFromExistingGroups?: boolean;
    createNewGroups?: boolean;
}
/**
 * Build request payload for service 'groupUser' action 'sync'.
 *
 * Usage: sync by userId and groupIds
 *
 * Server response type:         KalturaBulkUpload
 * Server failure response type: KalturaAPIException
 */
export declare class GroupUserSyncAction extends KalturaRequest<KalturaBulkUpload> {
    userId: string;
    groupIds: string;
    removeFromExistingGroups: boolean;
    createNewGroups: boolean;
    constructor(data: GroupUserSyncActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
