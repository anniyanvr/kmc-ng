import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaInteractivity } from './KalturaInteractivity';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface InteractivityAddActionArgs extends KalturaRequestArgs {
    entryId: string;
    kalturaInteractivity: KalturaInteractivity;
}
/**
 * Build request payload for service 'interactivity' action 'add'.
 *
 * Usage: Add a interactivity object
 *
 * Server response type:         KalturaInteractivity
 * Server failure response type: KalturaAPIException
 */
export declare class InteractivityAddAction extends KalturaRequest<KalturaInteractivity> {
    entryId: string;
    kalturaInteractivity: KalturaInteractivity;
    constructor(data: InteractivityAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
