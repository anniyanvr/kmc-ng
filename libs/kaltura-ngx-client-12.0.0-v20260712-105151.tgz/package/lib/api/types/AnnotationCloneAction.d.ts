import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaAnnotation } from './KalturaAnnotation';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AnnotationCloneActionArgs extends KalturaRequestArgs {
    id: string;
    entryId: string;
    parentId?: string;
}
/**
 * Build request payload for service 'annotation' action 'clone'.
 *
 * Usage: Clone cuePoint with id to given entry
 *
 * Server response type:         KalturaAnnotation
 * Server failure response type: KalturaAPIException
 */
export declare class AnnotationCloneAction extends KalturaRequest<KalturaAnnotation> {
    id: string;
    entryId: string;
    parentId: string;
    constructor(data: AnnotationCloneActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
