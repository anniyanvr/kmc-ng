import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaGroup } from './KalturaGroup';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface GroupGetActionArgs extends KalturaRequestArgs {
    groupId: string;
}
/**
 * Build request payload for service 'group' action 'get'.
 *
 * Usage: Retrieves a group object for a specified group ID
 *
 * Server response type:         KalturaGroup
 * Server failure response type: KalturaAPIException
 */
export declare class GroupGetAction extends KalturaRequest<KalturaGroup> {
    groupId: string;
    constructor(data: GroupGetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
