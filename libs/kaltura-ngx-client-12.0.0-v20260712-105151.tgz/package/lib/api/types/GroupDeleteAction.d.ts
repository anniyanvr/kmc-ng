import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaGroup } from './KalturaGroup';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface GroupDeleteActionArgs extends KalturaRequestArgs {
    groupId: string;
}
/**
 * Build request payload for service 'group' action 'delete'.
 *
 * Usage: Delete group by ID
 *
 * Server response type:         KalturaGroup
 * Server failure response type: KalturaAPIException
 */
export declare class GroupDeleteAction extends KalturaRequest<KalturaGroup> {
    groupId: string;
    constructor(data: GroupDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
