import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEntryVendorTask } from './KalturaEntryVendorTask';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryVendorTaskReplaceOutputActionArgs extends KalturaRequestArgs {
    id: number;
    newOutput: string;
}
/**
 * Build request payload for service 'entryVendorTask' action 'replaceOutput'.
 *
 *
 *
 * Server response type:         KalturaEntryVendorTask
 * Server failure response type: KalturaAPIException
 */
export declare class EntryVendorTaskReplaceOutputAction extends KalturaRequest<KalturaEntryVendorTask> {
    id: number;
    newOutput: string;
    constructor(data: EntryVendorTaskReplaceOutputActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
