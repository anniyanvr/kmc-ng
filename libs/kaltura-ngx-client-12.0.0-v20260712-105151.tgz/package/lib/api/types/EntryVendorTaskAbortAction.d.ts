import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEntryVendorTask } from './KalturaEntryVendorTask';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryVendorTaskAbortActionArgs extends KalturaRequestArgs {
    id: number;
    abortReason?: string;
}
/**
 * Build request payload for service 'entryVendorTask' action 'abort'.
 *
 * Usage: Cancel entry task. will only occur for task in PENDING or PENDING_MODERATION status
 *
 * Server response type:         KalturaEntryVendorTask
 * Server failure response type: KalturaAPIException
 */
export declare class EntryVendorTaskAbortAction extends KalturaRequest<KalturaEntryVendorTask> {
    id: number;
    abortReason: string;
    constructor(data: EntryVendorTaskAbortActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
