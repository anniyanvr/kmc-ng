import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEntryVendorTask } from './KalturaEntryVendorTask';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryVendorTaskAddActionArgs extends KalturaRequestArgs {
    entryVendorTask: KalturaEntryVendorTask;
}
/**
 * Build request payload for service 'entryVendorTask' action 'add'.
 *
 * Usage: Allows you to add a entry vendor task
 *
 * Server response type:         KalturaEntryVendorTask
 * Server failure response type: KalturaAPIException
 */
export declare class EntryVendorTaskAddAction extends KalturaRequest<KalturaEntryVendorTask> {
    entryVendorTask: KalturaEntryVendorTask;
    constructor(data: EntryVendorTaskAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
