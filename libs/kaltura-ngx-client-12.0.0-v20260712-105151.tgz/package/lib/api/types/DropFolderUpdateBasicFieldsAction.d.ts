import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDropFolder } from './KalturaDropFolder';
import { KalturaBasicFieldsDropFolder } from './KalturaBasicFieldsDropFolder';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DropFolderUpdateBasicFieldsActionArgs extends KalturaRequestArgs {
    dropFolderId: number;
    dropFolder: KalturaBasicFieldsDropFolder;
}
/**
 * Build request payload for service 'dropFolder' action 'updateBasicFields'.
 *
 *
 *
 * Server response type:         KalturaDropFolder
 * Server failure response type: KalturaAPIException
 */
export declare class DropFolderUpdateBasicFieldsAction extends KalturaRequest<KalturaDropFolder> {
    dropFolderId: number;
    dropFolder: KalturaBasicFieldsDropFolder;
    constructor(data: DropFolderUpdateBasicFieldsActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
