import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaInteractivity } from './KalturaInteractivity';
import { KalturaInteractivityDataFilter } from './KalturaInteractivityDataFilter';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface InteractivityGetActionArgs extends KalturaRequestArgs {
    entryId: string;
    dataFilter?: KalturaInteractivityDataFilter;
}
/**
 * Build request payload for service 'interactivity' action 'get'.
 *
 * Usage: Retrieve a interactivity object by entry id
 *
 * Server response type:         KalturaInteractivity
 * Server failure response type: KalturaAPIException
 */
export declare class InteractivityGetAction extends KalturaRequest<KalturaInteractivity> {
    entryId: string;
    dataFilter: KalturaInteractivityDataFilter;
    constructor(data: InteractivityGetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
