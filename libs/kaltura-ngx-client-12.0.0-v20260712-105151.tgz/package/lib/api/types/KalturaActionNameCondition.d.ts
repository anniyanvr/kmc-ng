import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRegexCondition, KalturaRegexConditionArgs } from './KalturaRegexCondition';
export interface KalturaActionNameConditionArgs extends KalturaRegexConditionArgs {
}
export declare class KalturaActionNameCondition extends KalturaRegexCondition {
    constructor(data?: KalturaActionNameConditionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
