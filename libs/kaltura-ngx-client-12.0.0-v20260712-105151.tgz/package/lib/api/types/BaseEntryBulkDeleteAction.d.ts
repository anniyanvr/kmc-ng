import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBaseEntryFilter } from './KalturaBaseEntryFilter';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BaseEntryBulkDeleteActionArgs extends KalturaRequestArgs {
    filter: KalturaBaseEntryFilter;
}
/**
 * Build request payload for service 'baseEntry' action 'bulkDelete'.
 *
 *
 *
 * Server response type:         number
 * Server failure response type: KalturaAPIException
 */
export declare class BaseEntryBulkDeleteAction extends KalturaRequest<number> {
    filter: KalturaBaseEntryFilter;
    constructor(data: BaseEntryBulkDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
