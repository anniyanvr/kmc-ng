import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaNullableBoolean } from './KalturaNullableBoolean';
import { KalturaRuleAction, KalturaRuleActionArgs } from './KalturaRuleAction';
export interface KalturaAccessControlServeRemoteEdgeServerActionArgs extends KalturaRuleActionArgs {
    edgeServerIds?: string;
    seamlessFallbackEnabled?: KalturaNullableBoolean;
}
export declare class KalturaAccessControlServeRemoteEdgeServerAction extends KalturaRuleAction {
    edgeServerIds: string;
    seamlessFallbackEnabled: KalturaNullableBoolean;
    constructor(data?: KalturaAccessControlServeRemoteEdgeServerActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
