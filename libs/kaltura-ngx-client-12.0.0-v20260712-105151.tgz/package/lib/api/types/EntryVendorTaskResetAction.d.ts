import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEntryVendorTask } from './KalturaEntryVendorTask';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryVendorTaskResetActionArgs extends KalturaRequestArgs {
    id: number;
    catalogItemId: number;
}
/**
 * Build request payload for service 'entryVendorTask' action 'reset'.
 *
 * Usage: Reset entry vendor task. change status back to pending with a new catalog item
 *
 * Server response type:         KalturaEntryVendorTask
 * Server failure response type: KalturaAPIException
 */
export declare class EntryVendorTaskResetAction extends KalturaRequest<KalturaEntryVendorTask> {
    id: number;
    catalogItemId: number;
    constructor(data: EntryVendorTaskResetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
