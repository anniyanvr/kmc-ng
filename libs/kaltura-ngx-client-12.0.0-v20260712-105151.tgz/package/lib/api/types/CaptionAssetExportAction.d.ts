import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaFlavorAsset } from './KalturaFlavorAsset';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CaptionAssetExportActionArgs extends KalturaRequestArgs {
    assetId: string;
    storageProfileId: number;
}
/**
 * Build request payload for service 'captionAsset' action 'export'.
 *
 * Usage: manually export an asset
 *
 * Server response type:         KalturaFlavorAsset
 * Server failure response type: KalturaAPIException
 */
export declare class CaptionAssetExportAction extends KalturaRequest<KalturaFlavorAsset> {
    assetId: string;
    storageProfileId: number;
    constructor(data: CaptionAssetExportActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
