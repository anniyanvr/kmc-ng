import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEntryVendorTask } from './KalturaEntryVendorTask';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryVendorTaskUpdateJobActionArgs extends KalturaRequestArgs {
    id: number;
    entryVendorTask: KalturaEntryVendorTask;
}
/**
 * Build request payload for service 'entryVendorTask' action 'updateJob'.
 *
 * Usage: Update entry vendor task. Only the properties that were set will be updated
 *
 * Server response type:         KalturaEntryVendorTask
 * Server failure response type: KalturaAPIException
 */
export declare class EntryVendorTaskUpdateJobAction extends KalturaRequest<KalturaEntryVendorTask> {
    id: number;
    entryVendorTask: KalturaEntryVendorTask;
    constructor(data: EntryVendorTaskUpdateJobActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
