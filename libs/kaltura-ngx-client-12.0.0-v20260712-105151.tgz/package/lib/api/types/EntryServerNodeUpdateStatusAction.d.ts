import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEntryServerNode } from './KalturaEntryServerNode';
import { KalturaEntryServerNodeStatus } from './KalturaEntryServerNodeStatus';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryServerNodeUpdateStatusActionArgs extends KalturaRequestArgs {
    id: string;
    status: KalturaEntryServerNodeStatus;
}
/**
 * Build request payload for service 'entryServerNode' action 'updateStatus'.
 *
 *
 *
 * Server response type:         KalturaEntryServerNode
 * Server failure response type: KalturaAPIException
 */
export declare class EntryServerNodeUpdateStatusAction extends KalturaRequest<KalturaEntryServerNode> {
    id: string;
    status: KalturaEntryServerNodeStatus;
    constructor(data: EntryServerNodeUpdateStatusActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
