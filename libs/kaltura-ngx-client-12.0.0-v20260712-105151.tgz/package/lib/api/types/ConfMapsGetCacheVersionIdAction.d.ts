import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ConfMapsGetCacheVersionIdActionArgs extends KalturaRequestArgs {
}
/**
 * Build request payload for service 'confMaps' action 'getCacheVersionId'.
 *
 * Usage: Get configuration map cache key
 *
 * Server response type:         string
 * Server failure response type: KalturaAPIException
 */
export declare class ConfMapsGetCacheVersionIdAction extends KalturaRequest<string> {
    constructor(data?: ConfMapsGetCacheVersionIdActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
