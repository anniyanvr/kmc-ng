import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEntryVendorTask } from './KalturaEntryVendorTask';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryVendorTaskExtendAccessKeyActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
 * Build request payload for service 'entryVendorTask' action 'extendAccessKey'.
 *
 * Usage: Extend access key in case the existing one has expired
 *
 * Server response type:         KalturaEntryVendorTask
 * Server failure response type: KalturaAPIException
 */
export declare class EntryVendorTaskExtendAccessKeyAction extends KalturaRequest<KalturaEntryVendorTask> {
    id: number;
    constructor(data: EntryVendorTaskExtendAccessKeyActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
