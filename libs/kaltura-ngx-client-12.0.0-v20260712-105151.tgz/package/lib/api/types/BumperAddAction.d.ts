import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBumper } from './KalturaBumper';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BumperAddActionArgs extends KalturaRequestArgs {
    entryId: string;
    bumper: KalturaBumper;
}
/**
 * Build request payload for service 'bumper' action 'add'.
 *
 * Usage: Adds a bumper to an entry
 *
 * Server response type:         KalturaBumper
 * Server failure response type: KalturaAPIException
 */
export declare class BumperAddAction extends KalturaRequest<KalturaBumper> {
    entryId: string;
    bumper: KalturaBumper;
    constructor(data: BumperAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
