import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBumper } from './KalturaBumper';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BumperGetActionArgs extends KalturaRequestArgs {
    entryId: string;
}
/**
 * Build request payload for service 'bumper' action 'get'.
 *
 * Usage: Allows to get the bumper
 *
 * Server response type:         KalturaBumper
 * Server failure response type: KalturaAPIException
 */
export declare class BumperGetAction extends KalturaRequest<KalturaBumper> {
    entryId: string;
    constructor(data: BumperGetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
