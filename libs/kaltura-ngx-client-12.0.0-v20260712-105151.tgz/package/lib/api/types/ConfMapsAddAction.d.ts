import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaConfMaps } from './KalturaConfMaps';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ConfMapsAddActionArgs extends KalturaRequestArgs {
    map: KalturaConfMaps;
}
/**
 * Build request payload for service 'confMaps' action 'add'.
 *
 * Usage: Add configuration map
 *
 * Server response type:         KalturaConfMaps
 * Server failure response type: KalturaAPIException
 */
export declare class ConfMapsAddAction extends KalturaRequest<KalturaConfMaps> {
    map: KalturaConfMaps;
    constructor(data: ConfMapsAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
