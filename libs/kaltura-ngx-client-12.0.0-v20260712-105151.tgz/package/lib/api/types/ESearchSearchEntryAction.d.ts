import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaESearchEntryResponse } from './KalturaESearchEntryResponse';
import { KalturaESearchEntryParams } from './KalturaESearchEntryParams';
import { KalturaPager } from './KalturaPager';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ESearchSearchEntryActionArgs extends KalturaRequestArgs {
    searchParams: KalturaESearchEntryParams;
    pager?: KalturaPager;
}
/**
 * Build request payload for service 'eSearch' action 'searchEntry'.
 *
 *
 *
 * Server response type:         KalturaESearchEntryResponse
 * Server failure response type: KalturaAPIException
 */
export declare class ESearchSearchEntryAction extends KalturaRequest<KalturaESearchEntryResponse> {
    searchParams: KalturaESearchEntryParams;
    pager: KalturaPager;
    constructor(data: ESearchSearchEntryActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
