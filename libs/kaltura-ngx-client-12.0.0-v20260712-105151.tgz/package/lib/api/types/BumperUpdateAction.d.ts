import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBumper } from './KalturaBumper';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BumperUpdateActionArgs extends KalturaRequestArgs {
    entryId: string;
    bumper: KalturaBumper;
}
/**
 * Build request payload for service 'bumper' action 'update'.
 *
 * Usage: Allows to update a bumper
 *
 * Server response type:         KalturaBumper
 * Server failure response type: KalturaAPIException
 */
export declare class BumperUpdateAction extends KalturaRequest<KalturaBumper> {
    entryId: string;
    bumper: KalturaBumper;
    constructor(data: BumperUpdateActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
