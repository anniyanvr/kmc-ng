import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaGroup } from './KalturaGroup';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface GroupUpdateActionArgs extends KalturaRequestArgs {
    groupId: string;
    group: KalturaGroup;
}
/**
 * Build request payload for service 'group' action 'update'.
 *
 * Usage: Update group by ID
 *
 * Server response type:         KalturaGroup
 * Server failure response type: KalturaAPIException
 */
export declare class GroupUpdateAction extends KalturaRequest<KalturaGroup> {
    groupId: string;
    group: KalturaGroup;
    constructor(data: GroupUpdateActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
