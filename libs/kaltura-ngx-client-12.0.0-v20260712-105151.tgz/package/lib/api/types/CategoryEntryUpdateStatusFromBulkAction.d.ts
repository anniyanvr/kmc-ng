import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBulkUpload } from './KalturaBulkUpload';
import { KalturaBulkUploadJobData } from './KalturaBulkUploadJobData';
import { KalturaBulkUploadCategoryEntryData } from './KalturaBulkUploadCategoryEntryData';
import { KalturaUploadRequest, KalturaUploadRequestArgs } from '../kaltura-upload-request';
export interface CategoryEntryUpdateStatusFromBulkActionArgs extends KalturaUploadRequestArgs {
    fileData: File;
    bulkUploadData?: KalturaBulkUploadJobData;
    bulkUploadCategoryEntryData?: KalturaBulkUploadCategoryEntryData;
}
/**
 * Build request payload for service 'categoryEntry' action 'updateStatusFromBulk'.
 *
 *
 *
 * Server response type:         KalturaBulkUpload
 * Server failure response type: KalturaAPIException
 */
export declare class CategoryEntryUpdateStatusFromBulkAction extends KalturaUploadRequest<KalturaBulkUpload> {
    fileData: File;
    bulkUploadData: KalturaBulkUploadJobData;
    bulkUploadCategoryEntryData: KalturaBulkUploadCategoryEntryData;
    constructor(data: CategoryEntryUpdateStatusFromBulkActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
