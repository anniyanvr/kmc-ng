import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryVendorTaskGetServeUrlActionArgs extends KalturaRequestArgs {
    filterType?: string;
    filterInput?: number;
    status?: number;
    dueDate?: string;
}
/**
 * Build request payload for service 'entryVendorTask' action 'getServeUrl'.
 *
 *
 *
 * Server response type:         string
 * Server failure response type: KalturaAPIException
 */
export declare class EntryVendorTaskGetServeUrlAction extends KalturaRequest<string> {
    filterType: string;
    filterInput: number;
    status: number;
    dueDate: string;
    constructor(data?: EntryVendorTaskGetServeUrlActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
