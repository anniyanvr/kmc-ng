import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEntryVendorTask } from './KalturaEntryVendorTask';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryVendorTaskGetActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
 * Build request payload for service 'entryVendorTask' action 'get'.
 *
 * Usage: Retrieve specific entry vendor task by id
 *
 * Server response type:         KalturaEntryVendorTask
 * Server failure response type: KalturaAPIException
 */
export declare class EntryVendorTaskGetAction extends KalturaRequest<KalturaEntryVendorTask> {
    id: number;
    constructor(data: EntryVendorTaskGetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
