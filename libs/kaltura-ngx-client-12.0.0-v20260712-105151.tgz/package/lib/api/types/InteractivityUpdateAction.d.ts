import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaInteractivity } from './KalturaInteractivity';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface InteractivityUpdateActionArgs extends KalturaRequestArgs {
    entryId: string;
    version: number;
    kalturaInteractivity: KalturaInteractivity;
}
/**
 * Build request payload for service 'interactivity' action 'update'.
 *
 * Usage: Update an existing interactivity object
 *
 * Server response type:         KalturaInteractivity
 * Server failure response type: KalturaAPIException
 */
export declare class InteractivityUpdateAction extends KalturaRequest<KalturaInteractivity> {
    entryId: string;
    version: number;
    kalturaInteractivity: KalturaInteractivity;
    constructor(data: InteractivityUpdateActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
