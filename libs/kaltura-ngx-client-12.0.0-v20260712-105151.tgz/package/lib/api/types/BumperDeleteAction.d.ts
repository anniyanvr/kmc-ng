import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBumper } from './KalturaBumper';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BumperDeleteActionArgs extends KalturaRequestArgs {
    entryId: string;
}
/**
 * Build request payload for service 'bumper' action 'delete'.
 *
 * Usage: Delete bumper by EntryId
 *
 * Server response type:         KalturaBumper
 * Server failure response type: KalturaAPIException
 */
export declare class BumperDeleteAction extends KalturaRequest<KalturaBumper> {
    entryId: string;
    constructor(data: BumperDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
