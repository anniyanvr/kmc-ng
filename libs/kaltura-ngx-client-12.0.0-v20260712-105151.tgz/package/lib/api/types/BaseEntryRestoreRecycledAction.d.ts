import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBaseEntry } from './KalturaBaseEntry';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BaseEntryRestoreRecycledActionArgs extends KalturaRequestArgs {
    entryId: string;
}
/**
 * Build request payload for service 'baseEntry' action 'restoreRecycled'.
 *
 * Usage: Restore the entry from the recycle bin
 *
 * Server response type:         KalturaBaseEntry
 * Server failure response type: KalturaAPIException
 */
export declare class BaseEntryRestoreRecycledAction extends KalturaRequest<KalturaBaseEntry> {
    entryId: string;
    constructor(data: BaseEntryRestoreRecycledActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
