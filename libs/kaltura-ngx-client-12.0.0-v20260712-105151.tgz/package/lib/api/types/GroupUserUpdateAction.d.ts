import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaGroupUser } from './KalturaGroupUser';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface GroupUserUpdateActionArgs extends KalturaRequestArgs {
    groupUserId: string;
    groupUser: KalturaGroupUser;
}
/**
 * Build request payload for service 'groupUser' action 'update'.
 *
 * Usage: update GroupUser
 *
 * Server response type:         KalturaGroupUser
 * Server failure response type: KalturaAPIException
 */
export declare class GroupUserUpdateAction extends KalturaRequest<KalturaGroupUser> {
    groupUserId: string;
    groupUser: KalturaGroupUser;
    constructor(data: GroupUserUpdateActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
