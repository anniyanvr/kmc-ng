import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaESearchCategoryResponse } from './KalturaESearchCategoryResponse';
import { KalturaESearchCategoryParams } from './KalturaESearchCategoryParams';
import { KalturaPager } from './KalturaPager';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ESearchSearchCategoryActionArgs extends KalturaRequestArgs {
    searchParams: KalturaESearchCategoryParams;
    pager?: KalturaPager;
}
/**
 * Build request payload for service 'eSearch' action 'searchCategory'.
 *
 *
 *
 * Server response type:         KalturaESearchCategoryResponse
 * Server failure response type: KalturaAPIException
 */
export declare class ESearchSearchCategoryAction extends KalturaRequest<KalturaESearchCategoryResponse> {
    searchParams: KalturaESearchCategoryParams;
    pager: KalturaPager;
    constructor(data: ESearchSearchCategoryActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
