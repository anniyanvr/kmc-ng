import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaObjectBase, KalturaObjectBaseArgs } from '../kaltura-object-base';
export interface KalturaAppRoleArgs extends KalturaObjectBaseArgs {
    appGuid?: string;
    userRoleId?: number;
}
export declare class KalturaAppRole extends KalturaObjectBase {
    appGuid: string;
    userRoleId: number;
    readonly createdAt: Date;
    readonly updatedAt: Date;
    constructor(data?: KalturaAppRoleArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
