import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaFileRequest, KalturaFileRequestArgs } from '../kaltura-file-request';
export interface BaseEntryServePlaybackKeyActionArgs extends KalturaFileRequestArgs {
    entryId: string;
}
/**
 * Build request payload for service 'baseEntry' action 'servePlaybackKey'.
 *
 * Usage: This action serves HLS encrypted key if access control is validated
 *
 * Server response type:         { url: string }
 * Server failure response type: KalturaAPIException
 */
export declare class BaseEntryServePlaybackKeyAction extends KalturaFileRequest {
    entryId: string;
    constructor(data: BaseEntryServePlaybackKeyActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
