import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCategoryFilter } from './KalturaCategoryFilter';
import { KalturaCsvAdditionalFieldInfo } from './KalturaCsvAdditionalFieldInfo';
import { KalturaKeyValue } from './KalturaKeyValue';
import { KalturaExportToCsvOptions } from './KalturaExportToCsvOptions';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CategoryExportToCsvActionArgs extends KalturaRequestArgs {
    filter?: KalturaCategoryFilter;
    metadataProfileId?: number;
    additionalFields?: KalturaCsvAdditionalFieldInfo[];
    mappedFields?: KalturaKeyValue[];
    options?: KalturaExportToCsvOptions;
}
/**
 * Build request payload for service 'category' action 'exportToCsv'.
 *
 * Usage: Creates a batch job that sends an email with a link to download a CSV containing a list of categories
 *
 * Server response type:         string
 * Server failure response type: KalturaAPIException
 */
export declare class CategoryExportToCsvAction extends KalturaRequest<string> {
    filter: KalturaCategoryFilter;
    metadataProfileId: number;
    additionalFields: KalturaCsvAdditionalFieldInfo[];
    mappedFields: KalturaKeyValue[];
    options: KalturaExportToCsvOptions;
    constructor(data?: CategoryExportToCsvActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
