import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEntryVendorTaskListResponse } from './KalturaEntryVendorTaskListResponse';
import { KalturaEntryVendorTaskFilter } from './KalturaEntryVendorTaskFilter';
import { KalturaFilterPager } from './KalturaFilterPager';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryVendorTaskGetJobsActionArgs extends KalturaRequestArgs {
    filter?: KalturaEntryVendorTaskFilter;
    pager?: KalturaFilterPager;
}
/**
 * Build request payload for service 'entryVendorTask' action 'getJobs'.
 *
 * Usage: get KalturaEntryVendorTask objects for specific vendor partner
 *
 * Server response type:         KalturaEntryVendorTaskListResponse
 * Server failure response type: KalturaAPIException
 */
export declare class EntryVendorTaskGetJobsAction extends KalturaRequest<KalturaEntryVendorTaskListResponse> {
    filter: KalturaEntryVendorTaskFilter;
    pager: KalturaFilterPager;
    constructor(data?: EntryVendorTaskGetJobsActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
